//our node header library that will create our pointers to the front and rear of our queue

struct Node { 
    int data;

    Node *link;
};

Node *front = NULL;
Node *rear = NULL;