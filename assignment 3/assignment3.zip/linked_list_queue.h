#include <iostream>
#include "Queue.h"

using std::cin;
using std::cout;
using std::endl;

//construct a linked list
Queue::Queue() {
    front = NULL;
    rear = NULL;
}
//check to see if our list is empty
bool Queue::isempty() {
    if(front == NULL && rear == NULL) {
        return true;
    }
    else {
        return false;
    }
}

//enter elements in our linked queue
void Queue::enqueue(int new_value) {
    Node *ptr = new Node();
    ptr->data = new_value;
    ptr->link = NULL;

    //check and see if the new_value being added is the first one in the queue
    if (front == NULL) {
        front = ptr;
        rear = ptr;
    }
    else {
        rear->link = ptr;
        rear = ptr;
    } 
}

//function to remove elements from the queue
int Queue::dequeue() {
    int dequeue_value = -1;
    //checks to see if queue is empty first
    if(isempty()) {
        cout << "Our queue is empty!" << endl;
        return 0;
    }
    else {
        //checks to see if there is only one element in queue
        if(front == rear) {
            return front->data;
            free(front);
            front = rear = NULL;
        }
        //takes away front value in queue and sets front equal to the next link in queue, return the value we dequeued
        else {
            Node *ptr = front;
            dequeue_value = front->data;
            front = front->link;
            free(ptr);
            return dequeue_value;
        }
    }
}

//function to see what our first  element in the queue is
int Queue::peek() {
    if(isempty()) 
        return -1;
    else 
        return front->data; 

}