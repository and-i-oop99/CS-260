#include <iostream>


class ArrQueue {
    public:
        //int arr_size = 10;
        int front = -1;
        int rear = -1;
        ArrQueue();
        bool is_empty();
        int enqueue(int new_value);
        int dequeue();
        int peek();
        int arr[10];
};