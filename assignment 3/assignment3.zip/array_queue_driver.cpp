#include <iostream>
#include "array_queue.h"


using std::cout;
using std::cin;
using std::endl;

int main() {
    //*TEST* to see if our functionalities are working correctly
    ArrQueue my_queue;
    my_queue.enqueue(6);
    my_queue.peek();
    my_queue.dequeue();
    my_queue.enqueue(10);
    my_queue.peek();
    my_queue.dequeue();
    my_queue.enqueue(11);
    my_queue.peek();
    my_queue.dequeue();
    my_queue.enqueue(115);
    my_queue.peek();
    my_queue.dequeue();
    my_queue.enqueue(135);
    my_queue.peek();
    my_queue.dequeue();
    my_queue.enqueue(158);
    my_queue.peek();
    my_queue.dequeue();
    my_queue.enqueue(145);
    my_queue.peek();
    my_queue.dequeue();
    my_queue.enqueue(189);
    my_queue.peek();
    my_queue.dequeue();
   //disgusting ik :(

    return 0;
}