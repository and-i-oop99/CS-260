#include "node_queue.h"

class Queue{
    public:
        Node *front;
        Node *rear;
        Queue();
        bool isempty();
        void enqueue(int new_value);
        int dequeue();
        int peek();

};