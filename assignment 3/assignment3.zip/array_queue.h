#include <iostream>
#include "array_queue_def.h"


using std::cin;
using std::cout;
using std::endl;

ArrQueue::ArrQueue() {
    front = -1;
    rear = -1;
}
//checks if our array queue is empty
bool ArrQueue::is_empty() {
    if (front == -1 && rear == -1) {
        return true;
    }
    else {
        return false;
    }
}
//function to add values to array queue
int ArrQueue::enqueue(int new_value) {
    //checks to see if array is full
    if(rear == 9 ) {
        cout << "Our queue is full!" << endl;
    }
    //increaments the front to 0 and moves the rear one position. rear is set to the new value
    else {
        if(front == -1) {
            front = 0;
            ++rear;
            arr[rear] = new_value;
        }
    }
    return 0;
} 
//function to remove elements from queue
int ArrQueue::dequeue() {
    //first check to see if queue is empty
    if(is_empty()) {
        cout << "Our queue is empty!" << endl;
    }
    //next check to see if there is one last element in the queue
    else {
        if(front == rear) {
            front = rear = -1;
        }
        //if neither conditions hold, increment the front of queue by one. 
        else {
            ++front;
        }
    }
    return 0;
}

int ArrQueue::peek() {
    if(is_empty()) {
        cout << "our queue is empty!" << endl;
    }
    else {
        cout << arr[front] << endl;
    }
    return 0;
}

