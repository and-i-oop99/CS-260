//Ian Delgado
//Mr. Jess
//CS 260
//Assignment 3

#include <iostream>
#include "linked_list_queue.h"


using std::cout;
using std::cin;
using std::endl;

int main() {
    //uses dynamic memory allociation to create a new Queue object pointer
    Queue *my_queue = new Queue();
    cout << "my_queue->peek(): " << my_queue->peek() << endl;

    //*TEST*add and remove values and peek to see if the functions are working correctly
    
    my_queue->enqueue(5);
    my_queue->enqueue(4);
    my_queue->enqueue(20);
    my_queue->enqueue(25);
    cout << "my_queue->peek(): " << my_queue->peek() << endl;

    my_queue ->dequeue();
    cout << "my_queue->peek(): " << my_queue->peek() << endl;

    my_queue ->dequeue();
    cout << "my_queue->peek(): " << my_queue->peek() << endl;
    my_queue->dequeue();
   cout << "my_queue->peek(): " << my_queue->peek() << endl;

    return 0;
}