#include "node.h"
#include <iostream>
#include <cstddef>
using namespace std;
#define SPACE 5

//binary search tree class
class BinarySearchTree {
    public:
        //node pointer that establishes our rooot
        Node *root;
        BinarySearchTree() {
            root = NULL;
        }
        //checks to see if the tree is empty
        bool is_empty() {
            //if root = null return true
            if(root == NULL) {
                return true;
            }
            //if root does not equal to true return false
            else {
                return false;
            }
        }
        //function to insert values into our tree. Take in a new node as an argument
        void insert_node(Node *new_node) {
            //check to see if the root is equal to NULL to either made new_node as the root or proceed to further conditions
            if(root == NULL) {
                //sets the new_node as root if root is not NULL
                root = new_node;
                cout << "Your tree now has a root!" << endl;
            }
            //create a temp pointer so we may traverse through the tree
            else {
                Node *temp =  root;
                //while the temp does not equal NULL, that means we can traverse the tree further
                while(temp != NULL) {
                    //first case that checks to see if the value wanting to be inserted in the tree already exisits
                    if(new_node->value == temp->value) {
                        cout << "That value already exists, please try another one"<< endl;
                        return;
                    }
                    //case that checks if the new value is less than the root and if the left pointer of the root is NULL
                    else if((new_node->value < temp->value) && (temp->left == NULL)) {
                        temp->left = new_node;
                        cout << "value has been inserted to the left!!" << endl;
                        break;
                    }
                    //if the root is not NULL, set the temp pointer to the left of the root until we have a left pointer that is NULL
                    else if(new_node->value < temp->value) {
                        temp = temp->left;
                    }
                    //check to see if the new_node has a greater value than the root and add it to the right if it does
                    else if((new_node->value > temp->value) && (temp->right == NULL)) {
                        temp->right = new_node;
                        cout << "value has been inserted to the right!!" << endl;
                        break;
                    }
                    //traverses through the list to the next right
                    else {
                        temp = temp->right;
                    }
                }
            }

        }




        //method to graphically print out function
        void print_bst(Node *r, int space) {
            if(r == NULL)  { //base case
                return;
            }
            
            space += SPACE; //increases distance between levels
            print_bst(r->right, space); //prints right child first
            cout << endl;
            for (int i = SPACE; i < space; i++) { //print the current node after space count
                cout << " ";
            }
            cout << r->value << "\n";
            print_bst(r->left, space); //now process left child
        }
        //method to use pre_order traversal to print value
        void pre_order(Node *r) { //search in the order of node, left, right
            if(r == NULL) {
                return;
            }
            //print value of node
            cout << r->value << " ";
            //now recurse on left of tree
            pre_order(r->left);
            //now right of tree
            pre_order(r->right);

        }
        //method to traverse and print tree using in_order technique 
        void in_order(Node *r) { //left, node, right
            //exits when we reach an address of NULL
            if(r==NULL) {
                return;
            }

            //recurse on left side of tree
            in_order(r->left);
            cout << r->value << " ";
            //now recurse on right side of tree
            in_order(r->right);
        }
        //method to print our tree in post-order traversal
        void post_order(Node *r) { //left, right, root
            //base case
            if(r == NULL) {
                return;
            }

            //recurse left side of tree
            post_order(r->left);
            //recurse right side of tree
            post_order(r->right);
            //now print value
            cout << r->value << " ";

        }
        //method to find the height of tree
        int height_of_tree(Node *r) {
            //base case if the root is NULL
            if(r == NULL) {
                return -1;
            }
            else {
                //find the height of each side of tree
                int left_height = height_of_tree(r->left);
                int right_height = height_of_tree(r->right);
                //find which height is greater and use the bigger height
                if(left_height > right_height) {
                    return (left_height + 1);
                }
                else {
                    return (right_height + 1);
                }
            }
        }
        //method that traverses the tree and prints the values on a given level
        void print_level_given(Node * r, int level) {
            //base case
            if(r == NULL) {
                return;
            }
            //print level 0
            else if (level == 0) {
                cout << r->value << " ";
            }
            //use recursion to go to the right and left of tree and print their levels.
            else  {
                print_level_given(r->left, level -1);
                print_level_given(r->right, level -1);
            }
        }
        //method that provides the height of tree and uses print_level_given to print the tree in level order
        void breadth_first_traversal(Node *r) {
            int h = height_of_tree(r);
            for(int i =0; i <= h; i++) {
                print_level_given(r,i);
            }
        }
        //method that finds the smallest value in the right side of the bst
        Node* min_value(Node *node) {
            Node *current = node;
            //traverse to find leftmost child in the right side of tree
            while(current->left != NULL) {
                current = current->left;
            }
            //return leftmost value
            cout << current->value;
            return current;
        }
        //method that deletes node of a given value
        Node *delete_node(Node *r, int v) {
            //base case
            if(r == NULL ) {
                return NULL;
            }
            //sees if value that is to be deleted is smaller than roots value to see if it resides in left of tree
            else if(v < r->value) {
                r->left = delete_node(r->left, v);
            }
            //check to see if value is greater than root value in order to see if value to be deleted is in right of tree
            else if(v > r->value) {
                r->right = delete_node(r->right, v);
            }
            //checks to see if value to be deleted is root
            else {
                //case if node has only one child or no children
                if(r->left == NULL) {
                    Node *temp = r->right;
                    delete r;
                    return temp;
                }
                else if(r->right == NULL) {
                    Node *temp = r->left;
                    delete r;
                    return temp;
                }
                else {
                    //case for tree node with 2 children. First get successor by getting the smallest value on the right of tree
                    Node *temp = min_value(r->right);
                    //copy value of temp to the right node
                    r->value = temp->value;
                    //delete the original spot of sucessor node
                    r->right = delete_node(r->right, temp->value);
                }
            }
            return r;
        }

};
