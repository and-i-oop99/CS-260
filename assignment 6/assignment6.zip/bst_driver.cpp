//Ian Delgado
//Joseph Jess
//CS 260
//Febuary 15th 2021

/*
Program that will create a binary search tree and do various operations such as insert nodes,
delete nodes, print the tree on the console, and print in pre-order, in-order, post-order, 
and breadth first traversal.
*/

#include <iostream>
#include "bst_tests.h"
using namespace std;

/*tests I want the program to pass (may add more nodes during actual test):
//the function that inserts and prints the tree
//insert_node() and print_bst() tests:
BinarySearchTree obj;
node1's value is  99;
node2's value is  79;
node3's value is  88;
node4's value is  56;
obj.insert_node(node1);
obj.insert_node(node2);
obj.insert_node(node3);
obj.insert_node(node4);



obj.print_bst;


Output: 
99,79(to the left of 99), 88(to the right of 79), 56(to the left of 79)


//the functions that print in the pre-order,in-order, post-order and breadth first traversal techniques
//also tests the function that prints the values in the given level
//pre_order(), in_order(), post_order(),breadth_first_traversal(), and print_level_given() tests:

BinarySearchTree obj;
node1's value is  99;
node2's value is  79;
node3's value is  88;
node4's value is  56;
obj.insert_node(node1);
obj.insert_node(node2);
obj.insert_node(node3);
obj.insert_node(node4);

obj.pre_order;
obj.in_order;
obj.post_order;
obj.breadth_first_traversal;
obj.print_level_given(0)


Output: 
99,79,56,88
56,79,88,99
56,88,79,99
99,79,56,88
99


//delete_node() test:

BinarySearchTree obj;
node1's value is  99;
node2's value is  79;
node3's value is  88;
node4's value is  56;
obj.insert_node(node1);
obj.insert_node(node2);
obj.insert_node(node3);
obj.insert_node(node4);
obj.delete_node(node1);



obj.in_order;


Output: 
56,79,88



//min_value() tests:
BinarySearchTree obj;
node1's value is  99;
node2's value is  79;
node3's value is  88;
node4's value is  56;
node5's value is 102;
obj.insert_node(node1);
obj.insert_node(node2);
obj.insert_node(node3);
obj.insert_node(node4);
obj.min_value(node1);



obj.print_bst;


Output: 
102

//height_of_tree() test:

BinarySearchTree obj;
node1's value is  99;
node2's value is  79;
node3's value is  88;
node4's value is  56;
node5's value is 102;
obj.insert_node(node1);
obj.insert_node(node2);
obj.insert_node(node3);
obj.insert_node(node4);

obj.height_of_tree(obj.root);


*/ 

int main() {
    

    
    
  //make object of TestFunction
   TestFunctions lol;
   lol.test_insert_node();
   cout << endl;
   cout << endl;
   //call test_pre_in_and_post_order()
   lol.test_pre_in_and_post_order();    
   cout << endl;
   cout << endl;
   //call test_bft_and_plg()
   lol.test_bft_and_plg();
   cout << endl;
   cout << endl;
   //call test_delete_node()
   lol.test_delete_node();
   cout << endl;
   cout << endl;
   //call test_min_value()
   lol.test_min_value();
    return 0;
}