#include <iostream>
#include "bst_functions.h"

using namespace std;


class TestFunctions {
    public:
        //method that tests the insert_node function
       void test_insert_node() {
           cout << "test insert_node(): " << endl;
           //create nodes using DMA
            Node *node1 = new Node();
            Node *node2 = new Node();
            Node *node3 = new Node();
            Node *node4 = new Node();
            Node *node5 = new Node();
            Node *node6 = new Node();
            Node *node7 = new Node();
            Node *node8 = new Node();
            //set the node's values
            node1->value = 99;
            node2->value = 79;
            node3->value = 88;
            node4->value = 56;
            node5->value = 19;
            node6->value = 420;
            node7->value = 710;
            node8->value = 666;
            //create an object of BinarySearchTree class
            BinarySearchTree obj;
            //insert nodes using insert_node() function
            obj.insert_node(node1);
            obj.insert_node(node2);
            obj.insert_node(node3);
            obj.insert_node(node4);
            obj.insert_node(node5);
            obj.insert_node(node6);
            obj.insert_node(node7);
            obj.insert_node(node8);
            //print the tree using print_bst() function
            obj.print_bst(obj.root,5);
       }
        //method that tests pre, in, and post order traversal
       void test_pre_in_and_post_order() {
           cout << "test pre-in-post_order(): " << endl;
           //create nodes using DMA
            Node *node1 = new Node();
            Node *node2 = new Node();
            Node *node3 = new Node();
            Node *node4 = new Node();
            Node *node5 = new Node();
            Node *node6 = new Node();
            Node *node7 = new Node();
            Node *node8 = new Node();
            //set the node's values
            node1->value = 99;
            node2->value = 79;
            node3->value = 88;
            node4->value = 56;
            node5->value = 19;
            node6->value = 420;
            node7->value = 710;
            node8->value = 666;
            //create an object of BinarySearchTreee
            BinarySearchTree obj;
            //insert nodes using insert_node() method
            obj.insert_node(node1);
            obj.insert_node(node2);
            obj.insert_node(node3);
            obj.insert_node(node4);
            obj.insert_node(node5);
            obj.insert_node(node6);
            obj.insert_node(node7);
            obj.insert_node(node8);
            //print the tree using print_bst() function 
            obj.print_bst(obj.root,5);
            //traverse and print the tree using pre_order() traversal
            obj.pre_order(obj.root);
            cout << endl;
            //traverse and print the tree using in_order() traversal
            obj.in_order(obj.root);
            cout << endl;
            //traverse and print the tree using post_order() traversal
            obj.post_order(obj.root);
            cout << endl;   
        }
        //method that tests breadth_first_traversal() and print_level_given() methods
        void test_bft_and_plg() {
            cout << "test breadth_first_traversal() and print_level_given(): " << endl;
            //create nodes using DMA
            Node *node1 = new Node();
            Node *node2 = new Node();
            Node *node3 = new Node();
            Node *node4 = new Node();
            Node *node5 = new Node();
            Node *node6 = new Node();
            Node *node7 = new Node();
            Node *node8 = new Node();
            //set the node's values
            node1->value = 99;
            node2->value = 79;
            node3->value = 88;
            node4->value = 56;
            node5->value = 19;
            node6->value = 420;
            node7->value = 710;
            node8->value = 666;
            //create an object of BinarySearchTreee
            BinarySearchTree obj;
            //insert nodes using insert_node() method
            obj.insert_node(node1);
            obj.insert_node(node2);
            obj.insert_node(node3);
            obj.insert_node(node4);
            obj.insert_node(node5);
            obj.insert_node(node6);
            obj.insert_node(node7);
            obj.insert_node(node8);
            cout << endl;
            cout << "bread_first_traversal: ";
            //print out values using breadth_first_traversal() method
            obj.breadth_first_traversal(obj.root);
            cout << endl;
            //print out level 2 of tree using print_level_given() method
            cout << "level 2 values: ";
            obj.print_level_given(obj.root, 2);

        }
        void test_delete_node() {
            cout << "test delete_node(): " << endl;
            //create nodes using DMA
            Node *node1 = new Node();
            Node *node2 = new Node();
            Node *node3 = new Node();
            Node *node4 = new Node();
            Node *node5 = new Node();
            Node *node6 = new Node();
            Node *node7 = new Node();
            Node *node8 = new Node();
            //set the node's values
            node1->value = 99;
            node2->value = 79;
            node3->value = 88;
            node4->value = 56;
            node5->value = 19;
            node6->value = 420;
            node7->value = 710;
            node8->value = 666;
            //create an object of BinarySearchTreee
            BinarySearchTree obj;
            //insert nodes using insert_node() method
            obj.insert_node(node1);
            obj.insert_node(node2);
            obj.insert_node(node3);
            obj.insert_node(node4);
            obj.insert_node(node5);
            obj.insert_node(node6);
            obj.insert_node(node7);
            obj.insert_node(node8);
            cout << endl;
            //use the in_order() function to see values of the tree in order
            obj.print_bst(obj.root, 5);
            cout << endl;
            //use the delete_node() function to delete node1
            obj.delete_node(obj.root, 99);
            //use the in_order() function to see values of tree now with node1 deleted
            obj.print_bst(obj.root, 5);
            cout << endl;
            obj.delete_node(obj.root, 666);
            cout << endl;
            obj.print_bst(obj.root, 5);
            

        }

        void test_min_value() {
            cout << "test min_value(): " << endl;
            //create nodes using DMA
            Node *node1 = new Node();
            Node *node2 = new Node();
            Node *node3 = new Node();
            Node *node4 = new Node();
            Node *node5 = new Node();
            Node *node6 = new Node();
            Node *node7 = new Node();
            Node *node8 = new Node();
            //set the node's values
            node1->value = 99;
            node2->value = 79;
            node3->value = 88;
            node4->value = 56;
            node5->value = 19;
            node6->value = 420;
            node7->value = 710;
            node8->value = 666;
            //create an object of BinarySearchTreee
            BinarySearchTree obj;
            //insert nodes using insert_node() method
            obj.insert_node(node1);
            obj.insert_node(node2);
            obj.insert_node(node3);
            obj.insert_node(node4);
            obj.insert_node(node5);
            obj.insert_node(node6);
            obj.insert_node(node7);
            obj.insert_node(node8);
            cout << endl;
            cout << "smallest value of tree: ";
            obj.min_value(obj.root);
        }

};