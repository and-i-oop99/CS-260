#include <cstddef>

class Node{
    public:
        int value; //key or data
        Node *left;
        Node *right;
        

        Node() {
            value = 0;
            left = NULL;
            right = NULL;
        }

        Node(int v) {
            value = v;
            left = NULL;
            right = NULL;
        }

};
