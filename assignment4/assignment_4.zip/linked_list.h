#include <iostream>
#include "linked_list_def.h"


using std::cin;
using std::cout;
using std::endl;

//constructor for our list
LinkedList::LinkedList() {
    head = NULL;
}
//set the head of the linked list to our first node
LinkedList::LinkedList(Node *n) {
    head = n;
}

//check to see if our list has an existing key
Node* LinkedList::node_exists(int k) {
    Node *temp =  NULL;
    //use ptr pointer to traverse through the list
    Node *ptr = head;
    while(ptr != NULL) {
        //check to see if your key is the same as the key value we passed as k
        if(ptr->key ==k) {
            temp =ptr;
        }
        //set pointer to the next node
        ptr = ptr->next;
    }
    return temp;
}

//method to append a node to a list
void LinkedList::append_node(Node *n) {
    if(node_exists(n->key) != NULL) {
        cout << "We already have a node with key value: " << n->key << ". Please use a node with a different key value" << endl;
    }
    else {
        if(head == NULL) {
            head = n;
            cout << "Node has been appended!" << endl;
        }
        else {
            //traverse through the list by accessing the next pointer to get the address of the next node until we get to NULL
            Node *ptr = head;
            while(ptr->next != NULL) {
                ptr = ptr->next;
            }
            //now that we are at the end of the list, append the next pointer to the pointer passed as the argument
            ptr->next = n;
            cout << "Node has been appended!" << endl;
        }
    }
}
//method to add a node at the begining of the list
void LinkedList::prepend_node(Node *n) {
    //check to see if the key value of the new node exists
    if(node_exists(n->key) != NULL) {

        cout << "We already have a node with: " << n->key << ". Please use a node with a different key value" << endl;
    }
    else {
        //we do not have to traverse the list like in append node, so just set the next pointer of whatever is passed as the arguement and set that as the head
        n->next = head;
        head = n;
        cout << "node prepended!" << endl;
    }

}

//appends a node in a particular position. Take in the argument of the key of the node to append after and the address of the Node of what we want to append
void LinkedList::insert_node_after(int k, Node *n) {
    //we must first check if our key  exists
    Node *ptr = node_exists(k);
    if(ptr==NULL) {
        cout << "There is NOT a node with key value: " << k << endl;
    }
    else {
    //checks to see if our key is unique
        if(node_exists(n->key) != NULL) {
            cout << "We already have a node with: " << n->key << ". Please use a node with a different key value" << endl;
        }
        //link the new node
        else {
            //set the address of the next pointer of the new node to the next addreess of the previous node
            n->next = ptr->next;
            //links the previous node to the new node being added
            ptr->next = n;
            cout << "node appended" << endl;
        }
    }
}

//method to delete node bya given position
void LinkedList::delete_node_by_position(int k) {
    if(head == NULL) {
        cout << "linked list empty, cannot delete anything." << endl;
    }
    else if (head != NULL) {
        //if we are removing the first node
        if(head->key == k) {
            //head is set to the next node
            head = head -> next;
            cout << "Node unlinked with key value: " << k << endl;
        }
        //deleting a node between two nodes
        else {
            //pointers to keep track of the previous and next position of the node we want to unlink
            Node *temp = NULL;
            Node *prevptr = head;
            Node *currptr = head->next;
            int val = 0;
            while(currptr != NULL) {
                //sets the next address of the pointer we are unlinking to NULL
                if(currptr->key == k) {
                    temp = currptr;
                    currptr = NULL;
                    val = temp->value;
                }
                else {
                    prevptr = prevptr->next;
                    currptr = currptr->next;
                }
            }
            if(temp != NULL) {
                //links the address of the previous pointer to the address stored in the node we are unlinking
                prevptr->next = temp->next;
                cout << "Node of position " << k << " with value: "<< val<< " unlinked" << endl;
            }
            else {
                cout << "Node with " << k << " value does not exist" << endl;
            }
        }
    }
}

//gets the value from the list based on the key
void LinkedList::get_value(int k) {
    Node *ptr = node_exists(k);
    //checks to see if a node with the key value exists
    if (ptr != NULL) {
        //sets the value of the node being pointed to equal to the new value
        cout << "the value of the node in position "<< k << " is: " <<  ptr->value << endl;
    }
    //message if key does not exist
    else {
        cout << "Node doesn't exist with key value: " << k << endl;
    }
}

//method to print the linked list
void LinkedList::print_list() {
    //checks to see if we have value in the link list
    if(head == NULL) {
        cout << "No nodes in list :(" << endl;
    }
    //use a temp pointer to iterate through the entire list
    else {
        cout << endl << "linked list values: ";
        Node *temp = head;
        //while loop to print out list
        while(temp != NULL) {
            cout << "(" << temp->key<<"," <<temp->value<<") -->";
            temp = temp->next;
        }
    }
}









