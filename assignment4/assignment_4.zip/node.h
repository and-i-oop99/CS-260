class Node {
    //make public to allows access throughout entire program
    public:
        int key;
        int value;
        Node *next;
        //node constructor to set initial values
        Node() {
            key = 0;
            value = 0;
            next = NULL;
        }
        Node(int k, int v) {
            key = k;
            value = v;
        }
    
};