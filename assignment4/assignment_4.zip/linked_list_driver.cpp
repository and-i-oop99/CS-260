//Ian Delgado
//Joseph Jess
//CS 260
//Assignment 4

/*program that creates a linked list and does operations to that linked list
such as adding, removing, updating, and printing our list. 
*/


#include <iostream>
#include "linked_list.h"

using std::cout;
using std::cin;
using std::endl;
//functions that we will use to test our code
class TestFunctions {
    public:

        //test for our append_node() functionality
        void test_append_node() {
            //creates our nodes we will test
            //create an object of LinkedList
            LinkedList s;
            Node *node1 = new Node();
            Node *node2 = new Node();
            Node *node3 = new Node();
            Node *node4 = new Node();
            //sets keys and values to our nodes
            node1->key = 1;
            node1->value = 17;
            node2->key = 2;
            node2->value = 99;
            node3->key = 3;
            node3->value = 217;
            node4->key = 4;
            node4->value = 854;

            s.append_node(node1);
            s.append_node(node2);
            s.append_node(node3);
            s.append_node(node4);

            cout << endl;

            s.print_list();
        }

        //test for delete_node_by_position() functionality
        void test_delete_node() {
            //creates our nodes we will test
            //create an object of LinkedList
            LinkedList s;
            Node *node1 = new Node();
            Node *node2 = new Node();
            Node *node3 = new Node();
            Node *node4 = new Node();
            Node *node5 = new Node();
            //sets keys and values to our nodes
            node1->key = 1;
            node1->value = 17;
            node2->key = 2;
            node2->value = 99;
            node3->key = 3;
            node3->value = 217;
            node4->key = 4;
            node4->value = 854;
            node5->key = 5;
            node5->value = 710;
            //append the nodes so we can delete them (except for node5 so we can test another part of the delete node funcionality)
            s.append_node(node1);
            s.append_node(node2);
            s.append_node(node3);
            s.append_node(node4);

            cout << endl;

            s.print_list();

            s.delete_node_by_position(2);
            //we should get an error message if it works
            s.delete_node_by_position(5);
            s.print_list();
        }

        //test for our node_exisits() functionality
        void test_node_exists() {
            //creates our nodes we will test
            //create an object of LinkedList
            LinkedList s;
            Node *node1 = new Node();
            Node *node2 = new Node();
            Node *node3 = new Node();
            Node *node4 = new Node();
            //sets keys and values to our nodes
            node1->key = 1;
            node1->value = 17;
            node2->key = 2;
            node2->value = 99;
            node3->key = 3;
            node3->value = 217;
            node4->key = 4;
            node4->value = 854;

            s.append_node(node1);
            s.append_node(node2);
            s.append_node(node3);
            s.append_node(node4);
            //if we try to append a node with a key that already exists, we will get an error message and therefore know if our the function is working
            s.append_node(node1);
        }

        //test function for our prepend_node() functionality
        void test_prepend_node() {
            //creates our nodes we will test
            //create an object of LinkedList
            LinkedList s;
            Node *node1 = new Node();
            Node *node2 = new Node();
            Node *node3 = new Node();
            Node *node4 = new Node();
            Node *node5 = new Node();
            //sets keys and values to our nodes
            node1->key = 1;
            node1->value = 17;
            node2->key = 2;
            node2->value = 99;
            node3->key = 3;
            node3->value = 217;
            node4->key = 4;
            node4->value = 854;
            node5->key = 5;
            node5->value = 420;

            //append the nodes
            s.append_node(node1);
            s.append_node(node2);
            s.append_node(node3);
            s.append_node(node4);
           //prepend the node, if it works, we will get a message that the node is prepended, 
           //if we try to prepend a node with an exisiting key, we will get an error message
            s.prepend_node(node5);
            s.prepend_node(node1);
            s.print_list();
        }

        //function to test our insert_node_after() functionality
        void test_insert_node_after() {
            //creates our nodes we will test
            //create an object of LinkedList
            LinkedList s;
            Node *node1 = new Node();
            Node *node2 = new Node();
            Node *node3 = new Node();
            Node *node4 = new Node();
            Node *node5 = new Node();
            //sets keys and values to our nodes
            node1->key = 1;
            node1->value = 17;
            node2->key = 2;
            node2->value = 99;
            node3->key = 3;
            node3->value = 217;
            node4->key = 4;
            node4->value = 854;
            node5->key = 5;
            node5->value = 420;

            //append the nodes
            s.append_node(node1);
            s.append_node(node2);
            s.append_node(node3);
            s.append_node(node4);
            //test to see if we get an error message when trying to append a node after a key that doesn't exist
            s.insert_node_after(6,node5);
            //test to see if the node will append after key 3
            s.insert_node_after(3,node5);
            //test to see if we get an error message for trying to append a node that already exists
            s.insert_node_after(3,node3);
            s.print_list();
        }
        //satisfies requirement 3 in assignment because we return the value along with doing other functionalities
        void test_get_value() {
            //creates our nodes we will test
            //create an object of LinkedList
            LinkedList s;
            Node *node1 = new Node();
            Node *node2 = new Node();
            Node *node3 = new Node();
            Node *node4 = new Node();
            //sets keys and values to our nodes
            node1->key = 1;
            node1->value = 17;
            node2->key = 2;
            node2->value = 99;
            node3->key = 3;
            node3->value = 217;
            node4->key = 4;
            node4->value = 854;
            //append the nodes
            s.append_node(node1);
            s.append_node(node2);
            s.append_node(node3);
            s.append_node(node4);

            cout << endl;

            s.print_list();
            //test to see if our nodes will update successfully
            cout << endl;
            s.get_value(1);
            s.get_value(2);
            s.get_value(3);
            s.print_list();
            cout << endl;
            //test to see what happens if we input an invalid key
            s.get_value(7);
        }

        //test function to see if our print_list() works
        void test_print_list() {
            //creates our nodes we will test
            //create an object of LinkedList
            LinkedList s;
            //test to see if we try to print out an empty list
            s.print_list();
            Node *node1 = new Node();
            Node *node2 = new Node();
            Node *node3 = new Node();
            Node *node4 = new Node();
            //sets keys and values to our nodes
            node1->key = 1;
            node1->value = 17;
            node2->key = 2;
            node2->value = 99;
            node3->key = 3;
            node3->value = 217;
            node4->key = 4;
            node4->value = 854;
            //append the nodes
            s.append_node(node1);
            s.append_node(node2);
            s.append_node(node3);
            s.append_node(node4);

            cout << endl;
            //test to see if we have a list with nodes in it.
            s.print_list();
        }

};

    
int main() {
    //create an object from our TestFunctions class and test the functions
    TestFunctions tst;
    //test append_node()
    cout << "test append_node(): " << endl;
    tst.test_append_node();
    //separate to make output look a little more organized
    cout << endl;
    cout << endl;
    //test delete_node_by_position()
    cout << "test delete_node_by_position(): " << endl;
    tst.test_delete_node();
    cout << endl;
    cout << endl;
    //test node_exists()
    cout<< "test node_exists(): " << endl;
    tst.test_node_exists();
    cout << endl;
    cout << endl;
    //test prepend_node()
    cout << "test prepend_node(): " << endl;
    tst.test_prepend_node();
    cout << endl;
    cout << endl;
    //test insert_node_after()
    cout << "test insert_node_after(): " << endl;
    tst.test_insert_node_after();
    cout << endl;
    cout << endl;
    //test update_node_by_key()
    cout << "test get_value(): " << endl;
    tst.test_get_value();
    cout << endl;
    cout << endl;
    //test print_list()
    cout << "test print_list(): " << endl;
    tst.test_print_list();

    return 0;
}