#include "node.h"


class LinkedList {
    public:
        Node *head;
        //constructor for our list
        LinkedList();
        //set the head of the linked list to our first node
        LinkedList(Node *n);
        //check to see if our list has an existing key
        //use Node* because this will be a method that returns a pointer
        Node* node_exists(int k);
        //method to append a node to a list
        void append_node(Node *n);
        //method to add a node at the begining of the list
        void prepend_node(Node *n);
        //appends a node in a particular position. Take in the argument of the key of the node to append after and the address of the Node of what we want to append
        void insert_node_after(int k, Node *n);
        //method to delete node bya given position
        void delete_node_by_position(int k);
        //updates the value of a node by given positon
        void get_value(int k);
        //method to print the linked list
        void print_list();
        //method to test that append_node() is working
        void test_append_node();
        
    
};      

    