//Ian Delgado
//Joseph Jess
//CS 260
//Febuary 25th 2021

//"Dumb" hashtable that has a hash function, insert function, delete function, and value exists function. 
// Overwrites values that have the same hash key

/* TESTS:
Tests I want the hash table to pass:

    is_empty() function:

    Check to see if hash table is empty using is_empty function. If sum variable is zero, then return true and 
    our list is empty!

    hash_fuction(): 

    To get the hash value return the remainder when we divide the key by the size of the table[] array. F
    For example, if our key was 807 and the table[] size was 10, we'd get 7 as the hash value

    insert_item() function:

    insert an item with a key and a value and use the hash_function() to get a hashed key value to insert in the
    hash table. Iterate through the table to see if the hash key value already exists and if one does, overwrite the value
    to be the new value.If key does not exists, insert the new value in the corresponding hash key value

    value_exists() function:

    check to see if a value already exists in the hash table by iterating through the hash table. If we
    find a value that matches the value passed as an argument, then print that the value already exists

    delete_item() function:

    delete an item in the hash table my iterating through the hash table and seeing if a hash fuction of a key passed
    matches a key in the hash table. If so, erase the key and value in the hash table and print out that the value has been removed

    print_table() function:

    print the hash table by iterating throught the table and printing out each key and value

*/


#include <iostream>
#include <list>
#include <cstring>

using namespace std;

using std::cout;
using std::cin;
using std::endl;

//HashTable class to create list and array of the table
class HashTable {
    private:
        //using list library, create an array based list with 10 open spaces
        static const int hashGroups = 10;
        list<pair<int, string >> table[hashGroups]; // List 1 index 0, list 2, index 1

    public:
        //functions we will be using for the hash table
        bool is_empty() const;
        int hash_function(int key);
        void insert_item(int key, string value);
        void remove_item(int key);
        //string search_table(int key);
        void print_table();
        void value_exists(int key, string value); 
        
};

//function to check if table is empty
bool HashTable::is_empty() const {
    int sum{};
    for(int i{}; i < hashGroups; i++) {
        sum += table[i].size();
    }
    //if sum is zero then return true
    if(!sum) {
        return true;
    }
    //otherwise return false
    return false;
}

//hash function that will change the key by divinding by 5 and giving the remainder
int HashTable::hash_function(int key) {
    //uses modulo of key and hashGroups to return the remainder and be used as the hash value
    return key % hashGroups; //key: 905 in return, this function will return 5

}

//method to insert items in the hash table
void HashTable::insert_item(int key, string value) {
    //set the hash_value equal to what hash_function returns
    int hash_value = hash_function(key);
    // set cell to table[hash_value] using auto& to make it a reference
    auto& cell = table[hash_value];
    //make a copy using auto of iterator
    auto iterator = begin(cell);
    //set key_exists to false
    bool key_exists = false;
    //create a for loop that ends when the interator is at the end of the hash_value
    for(; iterator != end(cell); iterator++) {
        //for loop that checks if the hash value of the iterator is equal to the key we want to insert
        if(hash_function(iterator->first) == hash_value) {
            key_exists = true;
            //if it does exisits, replace the value
            iterator->second = value;
            
            cout << "Value replaced" << endl;
            
            break;
        }
        //checks to see if a value already exists in the hash table
        if (iterator->second == value) {
            cout << "the value: " << value <<  " already exists in hash: " << iterator->first << endl;
        }
    }
    //check if key_exists is false
    if(!key_exists) {
        //pushes a value into the table[hash_value] array
        cell.emplace_back(key, value);
    }

    return;

}

//method that checks if a value exists in the hash table
void HashTable::value_exists(int key, string value) {
    //set the hash_value equal to what hash_function returns
    int hash_value = hash_function(key);
    // set cell to table[hash_value] using auto& to make it a reference
    auto& cell = table[hash_value];
    //make a copy using auto of iterator
    auto iterator = begin(cell);
    //set key_exists to false
    bool key_exists = false;
    //create a for loop that ends when the interator is at the end of the hash_value
    for(; iterator != end(cell); iterator++) {
        //checks to see if a value already exists in the hash table
        if (iterator->second == value) {
            cout << "the value: " << value <<  " already exists in hash: " << iterator->first << endl;
        }
    }
    //check if key_exists is false
    if(!key_exists) {
        //pushes a value into the table[hash_value] array
        cell.emplace_back(key, value);
    }

    return;

}

//method to remove an item from the hashtable
void HashTable::remove_item(int key) {
    //sets hash_value as whatever is returned from the hash_function
    int hash_value = hash_function(key);
    //set cell as a reference of table[hash_value]
    auto& cell = table[hash_value];
    //iterate through cell using begin() method
    auto iterator = begin(cell);
    //set key_exists to false
    bool key_exists = false;
    //create a for loop that continues until the iterator is at the last spot in cell
    for(; iterator != end(cell); iterator++) {
        //if the first copy of iterator (hash_value) is the key passed as the argument, set key exists to true and erase the itertor
        if(iterator->first == key) {
            key_exists = true;
            cout << "Hash key: " << hash_value << " Removed" << endl;
            iterator = cell.erase(iterator);
            break;
        }
    }
    //if key_exists is false, state that the key is not found
    if(!key_exists) {
        cout << "Key not found :( Please try another key" << endl;
    }

    return;

}

//method to print the hash table 
void HashTable::print_table() {
    //create a list of 1 and set that if i is less than hashGroups, continue the loop. Modify i by adding 1
    for(int i{}; i < hashGroups; i++) {
        //check if table[i] is equal to zero and continue
        if(table[i].size() == 0) {
            continue;
        }
        //create a iterator to iterator through table[i]
        auto iterator = table[i].begin();
        //loop through table[i] until we reach the end. Modify iterator by +1
        for(; iterator != table[i].end(); iterator++) {
            cout << "Key: " << hash_function(iterator->first) << " value: " << iterator->second << endl;
        }
    }
    return;
}


int main() {
    HashTable HT;
    if (HT.is_empty()) {
        cout << "correct. GOOD JOB!!" << endl;
    }
    else {
        cout << "uh oh, check your code!" << endl;
    }
    //For theses tests, I want to see that items with the same hash key are not duplicated when printed
    //and the items are printed in order by their hash key values
    HT.insert_item(666,"Lorde");
    HT.insert_item(6979,"Dula Peep");
    HT.insert_item(420,"Snoop Dog");
    HT.insert_item(710,"Laganja Estranja");
    HT.insert_item(857,"lil nas X");
    HT.insert_item(785, "Sponge Bob");
    HT.insert_item(333,"Satan");
    HT.insert_item(333,"Jesus");

    HT.print_table();
    //I want a message that says that the value lorde already exists in hash 666
    HT.value_exists(676,"Lorde");
    //I want a message that says which hash key was removed and if the key does not exists,
    //I want a message that indicates that the key was not found
    HT.remove_item(785);
    HT.remove_item(10);
    //if the table is not empty, I want a message saying "CORRECT ANSWER!! GOOD JOB!"
    if (HT.is_empty()) {
        cout << "uh oh, check your code!!" << endl;
    }
    else {
        cout << "CORRECT ANSWER!! GOOD JOB!" << endl;
    }
   
    return 0;
}